//
//  OOOoyalaPlayer+AppEvents.h
//  OoyalaSDK
//
//  Created on 10/31/18.
//  Copyright © 2018 Ooyala, Inc. All rights reserved.
//

#import "OOOoyalaPlayer.h"

#ifndef OOOoyalaPlayer_AppEvents_h
#define OOOoyalaPlayer_AppEvents_h

@interface OOOoyalaPlayer (AppEvents)

- (void)addAppLifeEventsObservers;

@end

#endif /* OOOoyalaPlayer_AppEvents_h */
