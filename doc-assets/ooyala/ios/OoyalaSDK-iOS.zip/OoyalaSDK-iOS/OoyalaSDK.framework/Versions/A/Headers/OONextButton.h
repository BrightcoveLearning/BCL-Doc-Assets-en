//
//  OONextButton.h
//  OoyalaSDK
//
//  Copyright © 2017 Ooyala, Inc. All rights reserved.
//

#import "OOScalableImageButton.h"


@interface OONextButton : OOScalableImageButton

@end
