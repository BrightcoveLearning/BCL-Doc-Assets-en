//
//  OOAirPlayButton.h
//  OoyalaSDK
//
//  Copyright © 2017 Ooyala, Inc. All rights reserved.
//

@import UIKit.UIButton;

@interface OOAirPlayButton : UIButton

@end
