#ifndef OoyalaIMASDK_h
#define OoyalaIMASDK_h

#import <OoyalaIMASDK/OOIMAManager.h>
#import <OoyalaIMASDK/OOIMAConfiguration.h>

#endif /* OoyalaIMASDK_h */
