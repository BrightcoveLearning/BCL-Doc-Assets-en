//
//  OOyalaAdobeAnalyticsSDK.h
//  OOyalaAdobeAnalyticsSDK
//
//  Copyright © 2016 Ooyala, Inc. All rights reserved.
//

#import <OoyalaAdobeAnalyticsSDK/OOAdobeAnalyticsManager.h>
#import <OoyalaAdobeAnalyticsSDK/OOAdobeHeartbeatConfiguration.h>