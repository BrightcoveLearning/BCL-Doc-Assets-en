To learn more about using this package, please read the information on https://github.com/ooyala/native-skin
