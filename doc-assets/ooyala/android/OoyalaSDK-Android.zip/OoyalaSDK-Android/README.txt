Current Version: 4.44.0_RC8

For the latest release notes, please refer to http://support.ooyala.com/documentation/concepts/mobile_sdk_android_release_notes.html

For developer documentation, please refer to http://support.ooyala.com/developers/documentation/concepts/chapter_sdk_android.html
