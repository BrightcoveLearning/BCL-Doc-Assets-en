//
//  OOVolumeButton.h
//  OoyalaSDK
//
//  Copyright © 2017 Ooyala, Inc. All rights reserved.
//

#import "OOScalableImageButton.h"

#ifndef OOVolumeButton_h
#define OOVolumeButton_h

@interface OOVolumeButton : OOScalableImageButton

@end

#endif /* OOVolumeButton */
