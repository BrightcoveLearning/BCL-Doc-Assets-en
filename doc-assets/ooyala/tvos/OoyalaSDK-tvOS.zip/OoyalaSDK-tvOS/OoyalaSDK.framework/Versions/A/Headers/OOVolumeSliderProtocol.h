//
//  OOVolumeSliderProtocol.h
//  OoyalaSDK
//
//  Copyright © 2017 Ooyala, Inc. All rights reserved.
//

@protocol OOVolumeSliderProtocol


@end
