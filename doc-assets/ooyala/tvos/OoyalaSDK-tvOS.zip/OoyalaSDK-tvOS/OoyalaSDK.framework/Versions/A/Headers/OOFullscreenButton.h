//
//  OOFullscreenButton.h
//  OoyalaSDK
//
//  Copyright © 2017 Ooyala, Inc. All rights reserved.
//

#import "OOScalableImageButton.h"

#ifndef OOFullscreenButton_h
#define OOFullscreenButton_h

@interface OOFullscreenButton : OOScalableImageButton

@end

#endif /* OOFullscreenButton_h */
