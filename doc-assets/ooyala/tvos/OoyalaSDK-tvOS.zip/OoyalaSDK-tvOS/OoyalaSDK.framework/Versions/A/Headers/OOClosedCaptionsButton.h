//
//  OOClosedCaptionsButton.h
//  OoyalaSDK
//
//  Copyright © 2017 Ooyala, Inc. All rights reserved.
//

#import "OOScalableImageButton.h"

#ifndef OOClosedCaptionsButton_h
#define OOClosedCaptionsButton_h

@interface OOClosedCaptionsButton : OOScalableImageButton

@end

#endif
