//
//  OOPreviousButton.h
//  OoyalaSDK
//
//  Copyright © 2017 Ooyala, Inc. All rights reserved.
//

#import "OOScalableImageButton.h"

#ifndef OOPreviousButton_h
#define OOPreviousButton_h

@interface OOPreviousButton : OOScalableImageButton

@end

#endif /* OOPreviousButton_h */
